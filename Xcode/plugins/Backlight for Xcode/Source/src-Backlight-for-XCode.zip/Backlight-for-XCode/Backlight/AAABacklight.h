//
//  AAABacklight.h
//  AAABacklight
//
//  Created by Aliksandr Andrashuk on 09.04.14.
//  Copyright (c) 2014 Aliksandr Andrashuk. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface AAABacklight : NSObject

@end