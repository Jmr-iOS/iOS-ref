Backlight for XCode
=========

Highlights the current editing line in Xcode

![](https://raw.githubusercontent.com/limejelly/Backlight-for-XCode/master/screenshot.png)

Installing:

1. Build with XCode
2. Restart XCode

Usage:

You can enable plugin by selecting menu Edit->Backlight->Line backlight.
Also you can change the color of selection by choosing Edit->Backlight->Edit line backlight color
